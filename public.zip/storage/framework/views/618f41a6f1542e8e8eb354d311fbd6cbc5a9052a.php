<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>ColourProfessionals</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&family=Roboto&family=Source+Sans+Pro&display=swap" rel="stylesheet">

    
    <link rel="shortcut icon" type="image/png" href="/favicon1.png">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('font/css/all.css')); ?>" rel="stylesheet"> <!--load all styles -->
</head>
<body>
    <?php echo $__env->make('includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<!-- Scripts -->
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

</html>
<?php /**PATH C:\wamp64\www\colourprofessional\resources\views\layouts\app.blade.php ENDPATH**/ ?>