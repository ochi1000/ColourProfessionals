

<?php $__env->startSection('title'); ?>
<p>Make Quotation</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Page wrapper  -->
<!-- =================Page wrapper div tag closes in the footer============================================= -->
<div class="page-wrapper" style="min-height: 250px;">
    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb bg-white">
        <div class="row align-items-center">
            <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                <h4 class="page-title">Quotations</h4>
            </div>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="white-box">
        <h3 class="box-title">Quotations and Receipts</h3>
        <br>
        <div class="row">
            <div class="col-sm-2"></div>
            <div class="col-sm-7"><input placeholder="Search For Reference Number" type="number" class="form-control" ></div>
            <div class="col-sm-3 d-flex justify-content-end"><a href="<?php echo e(route('quotations.create')); ?>" class="btn btn-primary">Add Quotation</a></div>
        </div>
        <br>
        <div class="row">
            <div class="col-sm-12">
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>

                <?php if($message = Session::get('error')): ?>
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover text-nowrap">
                        <thead>
                            <tr>
                                <th class="border-top-0">REF N</th>
                                <th class="border-top-0">Name</th>
                                <th class="border-top-0">Amount Paid</th>
                                <th class="border-top-0">Total Cost</th>
                                <th class="border-top-0">Date</th>
                                <th class="border-top-0">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $quotations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quotation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($quotation->quotation_number); ?></td>
                                <td><?php echo e($quotation->name); ?></td>
                                <td><?php echo e($quotation->total); ?></td>
                                <td><?php echo e($quotation->total); ?></td>
                                <td><?php echo e($quotation->created_at); ?></td>
                                <td><span><a href="<?php echo e(route('quotations.edit',$quotation->id)); ?>">edit</a> </span><span ><a style="color: red;" href="<?php echo e(route('quotations.show',$quotation->id)); ?>">delete</a> </span> </td>
                            </tr>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                            <tr>
                                <td>1</td>
                                <td>Deshmukh</td>
                                <td>Prohaska</td>
                                <td>₦1,000,000</td>
                                <td>admin</td>
                                <td>admin</td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>Deshmukh</td>
                                <td>Gaylord</td>
                                <td>₦1,000,000</td>
                                <td>member</td>
                                <td>member</td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>Sanghani</td>
                                <td>Gusikowski</td>
                                <td>₦1,000,000</td>
                                <td>developer</td>
                                <td>developer</td>
                            </tr>
                            <tr>
                                <td>4</td>
                                <td>Roshan</td>
                                <td>Rogahn</td>
                                <td>₦1,000,000</td>
                                <td>supporter</td>
                                <td>supporter</td>
                            </tr>
                            <tr>
                                <td>5</td>
                                <td>Joshi</td>
                                <td>Hickle</td>
                                <td>₦1,000,000</td>
                                <td>member</td>
                                <td>member</td>
                            </tr>
                            <tr>
                                <td>6</td>
                                <td>Nigam</td>
                                <td>Eichmann</td>
                                <td>₦1,000,000</td>
                                <td>supporter</td>
                                <td>supporter</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\colourprofessional\resources\views\admin\quotation.blade.php ENDPATH**/ ?>