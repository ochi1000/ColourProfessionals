

<?php $__env->startSection('content'); ?>
    <div class="products">
        <div class='container'>
            <div class='products-title'>
                <h2>Products & Services</h2>
            </div>
            <div>
                <h3>Architectural Design and Simulation</h3>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\colourprofessional\resources\views\productsnservices.blade.php ENDPATH**/ ?>