      <footer class="footer text-center"> 2021 © ColourProfessionals
      </footer>
</div>

<!-- All Jquery -->
<!-- ============================================================== -->
<script src="<?php echo e(asset('admin/plugins/bower_components/jquery/dist/jquery.min.js')); ?>"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="<?php echo e(asset('admin/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/app-style-switcher.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js')); ?>"></script>
<!--Wave Effects -->
<script src="<?php echo e(asset('admin/js/waves.js')); ?>"></script>
<!--Menu sidebar -->
<script src="<?php echo e(asset('admin/js/sidebarmenu.js')); ?>"></script>
<!--Custom JavaScript -->
<script src="<?php echo e(asset('admin/js/custom.js')); ?>"></script>
<!--This page JavaScript -->
<!--chartis chart-->
<script src="<?php echo e(asset('admin/plugins/bower_components/chartist/dist/chartist.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/bower_components/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/pages/dashboards/dashboard1.js')); ?>"></script>

<!-- Bootstrap JS -->
<!--  --><?php /**PATH C:\wamp64\www\colourprofessional\resources\views\admin\includes\footer.blade.php ENDPATH**/ ?>