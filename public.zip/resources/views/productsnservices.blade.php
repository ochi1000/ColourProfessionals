@extends('layouts.app')

@section('content')
    <div class="products">
        <div class='container'>
            <div class='products-title'>
                <h2>Products & Services</h2>
            </div>
            <div>
                <h3>Architectural Design and Simulation</h3>
            </div>
        </div>
    </div>
@endsection
