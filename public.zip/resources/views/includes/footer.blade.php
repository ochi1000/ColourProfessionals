<footer id="footer">
    <div class="container row">
        <div class="container show-for-small-screen text-center" style="font-size:.7rem;">
            <p class="text-highlight"><a class="text-decoration-none" href="https://wa.me/2349068919746">Searching for something else?</a></p>
        </div>
        <div class="col-lg-6">
            <h5>Contact Us</h5>
            <li><a class="text-decoration-none" href="tel:+2347069952473">+234 706 995 2473</a></li>
            <li><a class="text-decoration-none" href="tel:+2349068919746">+234 906 891 9746</a></li>
            <li><a class="text-decoration-none" href="tel:+2347030695156">+234 703 069 5156</a></li>
            <li><a class="text-decoration-none" href="mailto:customercare@colourprofessional.com.ng">customercare@colourprofessional.com.ng</a></li>
            <li><a class="text-decoration-none" href="">5 Divine Estate, Umuebulu 2, Etche L.G.A Rivers State</a></li>
        </div>
        <div class="col-lg-6">
            <h5>About</h5>
            <li><a class="text-decoration-none" href="/about-us">About Us</a></li>
            <li><a class="text-decoration-none" href="https://wa.me/2349068919746?text=Hello, I'm intrested in the price of your products">Pricing</a></li>

        </div>
    </div>
</footer>
